# CS2 Friends Bot V9 — ALL

A Discord.js v14 bot project upgraded from V8 with SQLite persistence and a Discord OAuth dashboard. Node.js 20+ recommended (Node 20.18+ recommended for native dependency compatibility).

## V9 dashboard improvements
- Public responsive leaderboard and player profile pages.
- Discord OAuth sign-in at `/auth/discord` with one-time state validation.
- `/admin` checks Discord guild `Manage Server`/`Administrator` permissions; optional `DASHBOARD_ADMIN_IDS` allowlist.
- Admin overview for recent matches, tournaments, warnings and player counts.
- JSON API at `/api/leaderboard` and health check at `/health`.
- SQLite storage at `data/cs2friends.sqlite`; if `data/players.json` exists on first start, the state is imported automatically. The old JSON file is retained as a backup.

## V8 features retained
- `/setup`, `/rolesetup`; ELO, level and community roles.
- `/queue join mode:5v5|2v2`, `/queue leave`, `/queue status`; ELO-balanced teams and private Team 1 / Team 2 voice rooms.
- `/win`, `/loss` recording based on players in the selected voice channel; +25 ELO / +100 XP for wins, -18 ELO / +50 XP for losses.
- `/profile`, `/stats`, `/rank`, `/leaderboard`, `/matches`, `/achievement`, `/daily`, and `/lvl` image card.
- `/elo add|remove|set`, `/warn`, `/warnings`, `/clearwarnings`, support ticket setup.
- `/veto-start`, `/pick`, `/ban`, `/veto-status`; persistent veto state and Team 2 Choice notification attempt with text-channel fallback.
- Tournament create/join/list/start/end and SteamID linking/unlinking.

## Install and run (Replit or VPS)
1. Upload/extract the `cs2-friends-bot-v9` folder into a Node.js Replit project.
2. In Secrets/environment variables, set `DISCORD_TOKEN`, `CLIENT_ID`, `DISCORD_CLIENT_SECRET`, `GUILD_ID`, and `DASHBOARD_BASE_URL`. Set `PORT` only if your host requires it. Optionally set `DASHBOARD_ADMIN_IDS` to comma-separated Discord user IDs.
3. In Discord Developer Portal → OAuth2 → Redirects, add the exact URL `https://YOUR-PUBLIC-DOMAIN/auth/callback` (must match `DASHBOARD_BASE_URL/auth/callback`).
4. Run:
   ```bash
   npm install
   npm run check
   npm run deploy
   npm start
   ```
5. Open the public host URL, use **Login with Discord**, then open `/admin`. Admin access is checked against the configured Discord server. Make sure the bot is in that server and can fetch members.
6. Invite the bot with `bot` and `applications.commands` scopes. Grant View Channels, Send Messages, Embed Links, Attach Files, Connect, Manage Channels and Manage Roles as needed. Move the bot role above all roles it manages.
7. Run `/rolesetup` once and `/setup` if you want the standard server layout.

## Dashboard endpoints
- `/` — public dashboard and leaderboard
- `/player/DISCORD_USER_ID` — player stats and recent matches
- `/auth/discord` — Discord login
- `/admin` — permission-protected admin overview
- `/api/leaderboard` — JSON leaderboard
- `/health` — health and storage status

## Important limitations
- This package can be syntax-checked locally, but a real Discord login/bot test requires your own valid Discord credentials and deployed public HTTPS URL.
- Team voice rooms are created but users must join them themselves. Match result commands only count non-bot members present in the selected voice channel at result time.
- Discord OAuth requires the `DISCORD_CLIENT_SECRET` from the Discord Developer Portal. Never share your bot token or client secret in chat or screenshots.
- SteamID linking stores a Steam identifier only; it does not automatically retrieve CS2 kills/deaths/ADR/HS. Live stats and automatic official match results need a trusted API or a CS2 server-side plugin.
- Tournament commands are registration/status management, not a fully automatic bracket/payment engine.
- `/pick` and `/ban` permission/turn logic remains the V8 implementation; test the veto flow in a private test server before competitive use.
- Sessions are in-memory and expire when the web process restarts; log in again after restart. Use HTTPS in production.

## Troubleshooting
- `Invalid token`: reset the bot token in Discord Developer Portal and update `DISCORD_TOKEN` in host Secrets.
- Commands missing: run `npm run deploy` and verify `CLIENT_ID` / `GUILD_ID`.
- OAuth errors: verify `CLIENT_ID`, `DISCORD_CLIENT_SECRET`, and exact callback URL, including https and trailing-slash consistency.
- Role sync errors: move the bot role above target roles and grant Manage Roles.
